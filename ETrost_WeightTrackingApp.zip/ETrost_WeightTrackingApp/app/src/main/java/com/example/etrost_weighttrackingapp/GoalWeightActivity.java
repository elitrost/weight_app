package com.example.etrost_weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GoalWeightActivity extends AppCompatActivity {

    // Declare variables
    EditText goalWeight;
    Button addWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        // Assign variables
        goalWeight = findViewById(R.id.goalWeightEditText);
        addWeight = findViewById(R.id.addWeightButton);

        // Set objective of add button
        addWeight.setOnClickListener(view -> {
            if (goalWeight.getText().toString() != null) {
                Toast.makeText(getApplicationContext(),
                        "Setting Goal...", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(view.getContext(), MainActivity.class);
                view.getContext().startActivity(intent);
            }
        });
    }
}