package com.example.etrost_weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class NotificationActivity extends AppCompatActivity {

    // Declare variables
    TextView permissions, notify;
    SwitchCompat allowSwitch;
    Button save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        // Assign variables
        permissions = findViewById(R.id.permissionsTextView);
        notify = findViewById(R.id.notificationTextView);
        allowSwitch = findViewById(R.id.allowSwitch);
        save = findViewById(R.id.buttonSave);

        // Set objective of save button
        save.setOnClickListener(view -> {
            Intent intent = new Intent(view.getContext(), GoalWeightActivity.class);
            view.getContext().startActivity(intent);
        });

    }
}