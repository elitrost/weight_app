package com.example.etrost_weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    // Declare variables
    EditText username, userPassword;
    Button signIn, signUp;
    TextView greetingTextView, orTextView;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Assign variables
        username = findViewById(R.id.editTextUserName);
        userPassword = findViewById(R.id.editTextPassword);
        signIn = findViewById(R.id.buttonSignIn);
        signUp = findViewById(R.id.buttonSignUp);
        greetingTextView = findViewById(R.id.greetingTextView);
        orTextView = findViewById(R.id.orTextView);
        db = new DatabaseHelper(this);

        // Set objective of sign in button
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String password = userPassword.getText().toString();

                if(user.equals("") || password.equals("")) {
                    Toast.makeText(getApplicationContext(),
                            "Please enter username and password.", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkUser = db.checkUsernamePassword(user, password);
                    if(checkUser == false) {
                        Toast.makeText(getApplicationContext(),
                                "Unable to sign in. Please check username and password.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(),
                                "Signing In...", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(view.getContext(), MainActivity.class);
                        view.getContext().startActivity(intent);
                    }
                }
            }
        });

        // Set objective of sign up button
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String password = userPassword.getText().toString();

                if(user.equals("") || password.equals("")) {
                    Toast.makeText(getApplicationContext(),
                            "Please enter username and password.", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkUser = db.checkUsername(user);
                    if(checkUser == true) {
                        Toast.makeText(getApplicationContext(),
                                "Username already exists. Please sign in or choose another username.", Toast.LENGTH_SHORT).show();
                    } else {
                        Boolean insert = db.insertData(user, password);
                        if(insert == true) {
                            Toast.makeText(getApplicationContext(),
                                    "Signing Up...", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(view.getContext(), NotificationActivity.class);
                            view.getContext().startActivity(intent);
                        } else {
                            Toast.makeText(getApplicationContext(),
                                    "Unable to sign up at this time.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }
}