package com.example.etrost_weighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.ContentView;
import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "WeightTrackingApp.db";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase myDB) {
        myDB.execSQL("create Table users(id INTEGER primary key autoincrement, username TEXT, password TEXT)");
        myDB.execSQL("create Table daily_weight(id INTEGER primary key autoincrement, dailyWeight TEXT, date TEXT)");
        myDB.execSQL("create Table goal(id INTEGER primary key autoincrement, goal TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase myDB, int i, int i1) {
        myDB.execSQL("drop Table if exists users");
    }

    // CREATE - Insert data
    public Boolean insertData(String username, String password) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = myDB.insert("users", null, contentValues);
        if(result == -1) {
            return false;
        } else {
            return true;
        }
    }

    // READ - Checks to see if user exists or not
    public Boolean checkUsername(String username) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from users where username = ?", new String[] {username});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public Boolean checkUsernamePassword (String username, String password) {
        SQLiteDatabase myDb = this.getWritableDatabase();
        Cursor cursor = myDb.rawQuery("Select * from users where username = ? and password = ?", new String[] {username, password});
        if(cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    // CREATE - Insert goal weight data
    public Boolean insertDailyWeight(String dailyWeight, String date) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("dailyWeight", dailyWeight);
        contentValues.put("date", date);
        long result = myDB.insert("daily_weight", null, contentValues);
        if(result == -1) {
            return false;
        } else {
            return true;
        }
    }

    // READ - get goal weight data
    public Cursor getDailyWeight(Integer id){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor res=db.rawQuery("Select * from daily_weight where id = " + id + "", null);
        return res;
    }

    // UPDATE - Update the goal weight data
    public Boolean dailyWeight(Integer id, String dailyWeight, String date) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("dailyWeight", dailyWeight);
        contentValues.put("date", date);
        long result = myDB.update("daily_weight", contentValues,"id = ?", new String[]{Integer.toString(id)});
        if(result == -1) {
            return false;
        } else {
            return true;
        }
    }

    // DELETE - Delete a specific goal weight
    public Integer deleteDailyWeight(Integer id){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.delete("daily_weight","id = ?",new String[]{Integer.toString(id)});
    }

    // CREATE - Insert data
    public Boolean insertGoal(String goalWeight) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("goalWeight", goalWeight);
        long result = myDB.insert("goal", null, contentValues);
        if(result == -1) {
            return false;
        } else {
            return true;
        }
    }

    // UPDATE - Update the goal weight
    public Boolean updateGoal(Integer id, String goalWeight) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("goalWeight", goalWeight);
        long result = myDB.update("goal", contentValues,"id = ?", new String[]{Integer.toString(id)});
        if(result == -1) {
            return false;
        } else {
            return true;
        }
    }

    // READ - get goal weight data
    public Cursor getGoal(Integer id){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor res=db.rawQuery("Select * from goal where id = " + id + "", null);
        return res;
    }
}
